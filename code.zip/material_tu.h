#pragma once
//material.h

#include"ray.h"
#include"hitable.h"
#include"vector.h"
#include"hitrecord.h"


